package br.com.inovacaointeligentes.servletBasico.Bussiness;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.inovacaointeligentes.servletBasico.Model.Empresa;

/**
 * Servlet implementation class EmpresaServlet
 */
@WebServlet("/empresa")
public class EmpresaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		PrintWriter out= response.getWriter();
		Empresa emp=new Empresa();
		Banco b=new Banco();
		SimpleDateFormat dt=new SimpleDateFormat("dd/MM/yyyy");
		Date dataCadastro=new Date();
		
			try {
				
				String text=request.getParameter("txtDataCadastro");
				dataCadastro = dt.parse(text);
				
			} catch (ParseException e) {
				throw new ServletException(e);
			}
			
		int contador=b.lista().size()+1;
		emp.setId(contador);
		emp.setCnpj(request.getParameter("txtCnpj"));
		emp.setFantasia(request.getParameter("txtNomeFantasia"));
		emp.setInscEsc(request.getParameter("txtInscEstadual"));
		emp.setDataCadastro(dataCadastro);
		
		b.adiciona(emp);
		/*out.println("<a href='"+"/servletBasico/index.html'> Voltar"+"</a>");
		out.println();
		out.println("<p> Empresa: "+emp.getCnpj()+" - "+emp.getFantasia()+" de Inscri��o Estadual: "+emp.getInscEsc()+" , salva Com sucesso!! </p>");
		out.println("<p>Empresa cadastrada</p>");*/
		/*RequestDispatcher rd= request.getRequestDispatcher("/NovaEmpresaCriada.jsp");
		request.setAttribute("id", emp.getId());
		request.setAttribute("Empresa", emp.getFantasia());
		request.setAttribute("cnpj", emp.getCnpj());
		request.setAttribute("incricaoEstdual", emp.getInscEsc());*/		
		//rd.forward(request, response);
		request.setAttribute("empresa", emp);
		response.sendRedirect("/servletBasico/lista");
		
		
		
	}

}
