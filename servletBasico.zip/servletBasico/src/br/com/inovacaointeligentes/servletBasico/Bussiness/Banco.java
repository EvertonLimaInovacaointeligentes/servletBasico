package br.com.inovacaointeligentes.servletBasico.Bussiness;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.taglibs.standard.tag.rt.fmt.ParseDateTag;

import com.sun.javafx.binding.StringFormatter;

import br.com.inovacaointeligentes.servletBasico.Model.Empresa;

public class Banco{
	private static List<Empresa>lista=new ArrayList<>();
	private static Integer chaveSequencial;
	private StringFormatter formato;
	static
	{
		Empresa emp=new Empresa();
		emp.setId(1);
		emp.setCnpj("77777777777777");
		emp.setFantasia("Inovacao Inteligentes");
		emp.setInscEsc("6635335");
		SimpleDateFormat dt=new SimpleDateFormat("dd/MM/yyyy");
		Date dataCadastro=new Date();		
				try {
					dataCadastro = dt.parse("01/02/2019");
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				emp.setDataCadastro(dataCadastro);
									
	    
		Empresa emp2=new Empresa();
		emp2.setId(2);
		emp2.setCnpj("88888888888888");
		emp2.setFantasia("Alura");
		emp2.setInscEsc("88822");
		SimpleDateFormat dt2=new SimpleDateFormat("dd/MM/yyyy");
		Date dataCadastro2=new Date();		
				try {
					dataCadastro = dt2.parse("01/03/2019");
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				emp2.setDataCadastro(dataCadastro);
		
		Banco.lista.add(emp);
		Banco.lista.add(emp2);
		chaveSequencial=lista.size()+1;
	}
public void adiciona(Empresa emp)
{
 	
  Banco.lista.add(emp);
  Banco.chaveSequencial=lista.size()+1;
}
public Empresa consulta(String cnpj)
{
	Empresa empresa=new Empresa();
	 for(Empresa emp:Banco.lista)
	 {
		 if(emp.getCnpj()==cnpj)
		 {
			 empresa=emp;
			 break;
		 }
	 }
	 return empresa;
	
}
public Empresa consultaID(int id)
{
	Empresa empresa=new Empresa();
	for(Empresa temp:Banco.lista)
	{
		if(temp.getId()==id)
		{
			empresa.setId(id);
			empresa.setCnpj(temp.getCnpj());
			empresa.setFantasia(temp.getFantasia());
			empresa.setInscEsc(temp.getInscEsc());
			empresa.setDataCadastro(temp.getDataCadastro());
			break;
		}
	}
	//return empresa;*/
    
    return  empresa; 
}
public List<Empresa> lista()
{
	return Banco.lista;
}
public void editar(Empresa emp)
{
	
	        Empresa empresa=consultaID(emp.getId());
	        for(Empresa temp:Banco.lista)
	        {
	        	if(temp.getId()==emp.getId())
	        	{
	        		temp.setCnpj(emp.getCnpj());
	        		temp.setDataCadastro(emp.getDataCadastro());
	        		temp.setFantasia(emp.getFantasia());
	        		temp.setInscEsc(emp.getInscEsc());
	        		break;
	        	}
	       // Empresa empresa=new Empresa();
	        //Banco.lista.remove(emp.getId());
	        
	        /*empresa.setCnpj(emp.getCnpj());
	        empresa.setDataCadastro(emp.getDataCadastro());
	        empresa.setFantasia(emp.getFantasia());
	        empresa.setInscEsc(emp.getInscEsc());
	        Banco.lista.add(emp.getId()-1, empresa);*/
			
		
	}
			//break;
	//	}
	//}
}
public void deletar(int id)
{
	int total=lista.size()-id;
	lista.remove(total);
}
}
