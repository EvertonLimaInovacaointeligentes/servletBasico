package br.com.inovacaointeligentes.servletBasico.Bussiness;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.html.HTMLEditorKit.Parser;

/**
 * Servlet implementation class removerEmpresa
 */
@WebServlet("/remover")
public class removerEmpresa extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public removerEmpresa() {
        super();
        // TODO Auto-generated constructor stub
    }
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
    public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

    	// TODO Auto-generated method stub
    	int id=Integer.parseInt(req.getParameter("id"));
    	Banco bd=new Banco();
    	bd.deletar(id);
    	res.sendRedirect("lista");
    	//super.service(req, res);
    }
	
}
