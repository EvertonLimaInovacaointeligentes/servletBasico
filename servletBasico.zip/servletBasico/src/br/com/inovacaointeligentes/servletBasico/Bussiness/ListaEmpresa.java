package br.com.inovacaointeligentes.servletBasico.Bussiness;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.inovacaointeligentes.servletBasico.Model.Empresa;

/**
 * Servlet implementation class ListaEmpresa
 */
@WebServlet("/lista")
public class ListaEmpresa extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Banco b=new Banco();
		List<Empresa> lista=b.lista();
		
		RequestDispatcher rd=request.getRequestDispatcher("/Empresas.jsp");
		request.setAttribute("empresas", lista);		
		rd.forward(request, response);
	}

}
