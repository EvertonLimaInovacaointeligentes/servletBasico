package br.com.inovacaointeligentes.servletBasico.Bussiness;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.inovacaointeligentes.servletBasico.Model.Empresa;

/**
 * Servlet implementation class Atualiza
 */
@WebServlet("/Atualiza")
public class Atualiza extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Atualiza() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Banco bd=new Banco();
		Empresa temp=new Empresa();
		temp.setId(Integer.parseInt(request.getParameter("txtId")));
		temp.setCnpj(request.getParameter("txtCnpj"));
		temp.setFantasia(request.getParameter("txtNomeFantasia"));
		temp.setInscEsc(request.getParameter("txtInscEstadual"));
		//temp.setDataCadastro(Date.parse(request.getParameter("txtDataCadastro")));
		SimpleDateFormat dt=new SimpleDateFormat("dd/MM/yyyy");
		Date dataCadastro=new Date();
		
			try {
				
				String text=request.getParameter("txtDataCadastro");
				dataCadastro = dt.parse(text);
				temp.setDataCadastro(dataCadastro);
				
			} catch (ParseException e) {
				throw new ServletException(e);
			}
		
		if(bd.consultaID(temp.getId())!=null)
		{
			bd.editar(temp);
			response.sendRedirect("lista");
		}
	}


}
