package br.com.inovacaointeligentes.servletBasico.Bussiness;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.inovacaointeligentes.servletBasico.Model.Empresa;

@WebServlet("/detalhe")
public class EmpresaDetalhe extends HttpServlet{

	
	private static final long serialVersionUID = 1L;
	
protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
{
   int id=Integer.parseInt(request.getParameter("id"));
   Banco bd=new Banco();
   Empresa empresa=bd.consultaID(id);
   RequestDispatcher rd=request.getRequestDispatcher("detalhe.jsp");
   request.setAttribute("empresa", empresa);
   rd.forward(request, response);

}
	}

}
