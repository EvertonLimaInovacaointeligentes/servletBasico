package br.com.inovacaointeligentes.servletBasico.Model;

import java.util.Date;

public class Empresa {

	private Integer Id;
	private String Cnpj;
	private String Fantasia;
	private String InscEsc;
	private Date DataCadastro=new Date();

public Integer getId() {
	return Id;
}
public void setId(Integer id) {
	Id = id;
}
public String getCnpj() {
	return Cnpj;
}
public void setCnpj(String cnpj) {
	Cnpj = cnpj;
}
public String getFantasia() {
	return Fantasia;
}
public void setFantasia(String fantasia) {
	Fantasia = fantasia;
}
public String getInscEsc() {
	return InscEsc;
}
public void setInscEsc(String inscEsc) {
	InscEsc = inscEsc;
}

public Date getDataCadastro() {
	return DataCadastro;
}
public void setDataCadastro(Date dataCadastro) {
	DataCadastro = dataCadastro;
}  
}
